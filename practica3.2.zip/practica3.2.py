n=int(input("Ingrese un numero entero:"))
acumulador=0
k=0

while k<n:
    k=k+1
    acumulador=acumulador+k
print("su suma es:", acumulador)
    
