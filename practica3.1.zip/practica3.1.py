n=1
while n<=10:
    print(n)
    n=n+1
print("end")